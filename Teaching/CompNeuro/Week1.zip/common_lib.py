from PyDSTool import pointset_to_traj, Pointset

def pcw_protocol(DS, prot_list):
    """protocol list of dictionaries with any of the keys 'pars',
    'ics', 'tdata', suitable for sending directly to DS.set method
    """
    orig_ics = DS.initialconditions.copy()
    t = 0
    for i, stage_dict in enumerate(prot_list):
        if 'pars' in stage_dict:
            DS.set(pars=stage_dict['pars'])
        if 'ics' in stage_dict:
            DS.set(ics=stage_dict['ics'])
        if 'tdata' in stage_dict:
            DS.set(tdata=stage_dict['tdata'])
        traj = DS.compute('test')
        if i == 0:
            pts = traj.sample()
            t = pts['t'][-1]
            DS.set(ics=pts[-1])
        else:
            new_pts = traj.sample()
            new_pts.indepvararray += t
            pts.extend(new_pts, skipMatchingIndepvar=True)
            t = new_pts['t'][-1]
            DS.set(ics=pts[-1])
    DS.set(ics=orig_ics)
    return pointset_to_traj(pts), pts
